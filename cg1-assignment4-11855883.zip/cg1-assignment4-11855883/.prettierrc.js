module.exports = {
  printWidth: 80,
  endOfLine: 'auto',
  singleQuote: true,
  bracketSpacing: true,
  ...require('gts/.prettierrc.json'),
};
